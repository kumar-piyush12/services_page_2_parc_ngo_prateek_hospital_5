import logo from '../assets/logo.jpeg';
import service1 from '../assets/service1.jpg'

export{
 logo,
 service1
};