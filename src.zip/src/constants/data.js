// import images from './images'

// const logo = [
//  {
//   logo: images.logo,
//  },
// ];

// const service1 = [
//  {
//   service1: images.service1,
//  },
// ];

// export default { logo, service1 }