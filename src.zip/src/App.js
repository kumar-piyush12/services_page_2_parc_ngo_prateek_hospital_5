import './App.css';
import Service1 from './components/service1/service1'
import Service2 from './components/service1/service1'
import Service3 from './components/service1/service1'
import Service4 from './components/service1/service1'
import Service5 from './components/service1/service1'
import Service6 from './components/service1/service1'
import Service7 from './components/service1/service1'
import Service8 from './components/service1/service1'
import Service9 from './components/service1/service1'
import Service10 from './components/service1/service1'
import Service11 from './components/service1/service1'


function App() {
  return (
    <div className='App'>
      <Service1 />
      <Service2 />
      <Service3 />
      <Service4 />
      <Service5 />
      <Service6 />
      <Service6 />
      <Service7 />
      <Service8 />
      <Service9 />
      <Service10 />
      <Service11 />
    </div>
  )
}

export default App;
